-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2019 at 04:19 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sidat`
--

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

CREATE TABLE `bidang` (
  `id_bidang` char(5) NOT NULL,
  `nama_bid` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`id_bidang`, `nama_bid`, `password`) VALUES
('01', 'Sekretariat', '5b401bccb11dc0374b6a93ab182bf4d4'),
('02', 'Budidaya', 'd576556d436c873e5c458bcdd80a0aeb'),
('03', 'Tangkap', 'faac1a3021db3492f6a87d937f712f26'),
('04', 'pemberdayaan', '29d49d9574086a15509d7740242235ab');

-- --------------------------------------------------------

--
-- Table structure for table `bulan`
--

CREATE TABLE `bulan` (
  `id_bulan` varchar(3) NOT NULL,
  `bulan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bulan`
--

INSERT INTO `bulan` (`id_bulan`, `bulan`) VALUES
('001', 'Januari'),
('002', 'Februari'),
('003', 'Maret'),
('004', 'April'),
('005', 'Mei'),
('006', 'Juni'),
('007', 'Juli'),
('008', 'Agustus'),
('009', 'September'),
('010', 'Oktober'),
('011', 'November'),
('012', 'Desember');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan`
--

CREATE TABLE `kegiatan` (
  `id_keg` int(6) NOT NULL,
  `id_prog` char(6) NOT NULL,
  `nama_keg` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kegiatan`
--

INSERT INTO `kegiatan` (`id_keg`, `id_prog`, `nama_keg`) VALUES
(1, '002', 'Pengelolaan Balai Benih Ikan'),
(2, '002', 'Pengembangan Ikan Hias Sukabumi'),
(3, '002', 'Pengembangan Sapras Usaha Pembesaran Ikan'),
(4, '002', 'Pelatihan dan Pembinaan Pembudidaya Ikan'),
(5, '002', 'Pengembangan Kawasan Cluster Perikanan Budidaya'),
(6, '002', 'Sertifikasi CPIB dan CBIB'),
(7, '002', 'Gerakan Pakan Mandiri'),
(8, '002', 'Bantuan Benih dan Pakan Ikan'),
(9, '002', 'Pengembangan Sidat'),
(10, '002', 'Pengembangan Sistem Kesehatan Ikan dan Lingkungan'),
(11, '002', 'Pengembangan Sistem Kesehatan Ikan dan Lingkungan'),
(12, '002', 'Perlindungan Sumberdaya Perikanan '),
(13, '003', 'Pemanfaatan dan pemulihan Sumberdaya Kelautan dan Perikanan Secara Terpadu dan Berkelanjutan'),
(14, '003', 'Peningkatan kapasitas nelayan '),
(15, '003', 'Pengelolaan TPI'),
(16, '003', 'Fasilitasi Rekomendasi SIUP dan SIPI'),
(17, '003', 'Pencatatan Armada Penangkapan Ikan'),
(18, '003', 'Pengadaan Alat Bantu Penangkapan Ikan'),
(19, '003', 'Pengadaan Alat Tangkap'),
(20, '003', 'Pengadaan Kapal'),
(21, '003', 'Pengadaan Sarana Untuk Nelayan'),
(22, '003', 'Pengadaan Sarana Untuk Nelayan'),
(23, '003', 'Pengelolaan dan Penyediaan Sarana dan Prasarana TPI'),
(24, '004', 'Diversifikasi Produk dan Peningkatan Mutu Hasil Perikanan'),
(25, '004', 'Pengelolaan Pasar Ikan'),
(26, '004', 'Pengembangan Jaringan Distribusi dan Pemasaran Hasil perikanan'),
(27, '004', 'Pengelolaan Sentra Lembursitu dan Bantargadung'),
(28, '004', 'Peningkatan Kelembagaan UMKM'),
(29, '004', 'Pembinaan Kehidupan Nelayan, Pokdakan dan Poklahsar'),
(30, '004', 'Pendampingan Asuransi dan Sertifikasi Hak Atas Tanah Pelaku Usaha Perikanan'),
(31, '004', 'Perlindungan Pelaku Usaha Perikanan'),
(32, '004', 'Pendampingan Asuransi Nelayan'),
(33, '004', 'Pengembangan sarana dan Prasarana Pengelolaan dan Pemasaran Hasil Perikanan'),
(34, '004', 'Pengelolaan Rumah Kemasan Lembursitu'),
(35, '004', 'Pengingkatan kapasitas dan Mutu Produk Perikanan'),
(37, '002', 'ikan hiu gendut');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` char(10) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('m01', '594b5a31a8ed8a091a566201d3ca232d');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `id_prog` char(6) NOT NULL,
  `id_bidang` char(5) NOT NULL,
  `nama_prog` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`id_prog`, `id_bidang`, `nama_prog`) VALUES
('002', '02', 'PROGRAM PENGEMBANGAN PERIKANAN BUDIDAYA'),
('003', '03', 'PROGRAM PENGEMBANGAN PERIKANAN TANGKAP'),
('004', '04', 'PENINGKATAN KESEJAHTERAAN PELAKU PERIKANAN');

-- --------------------------------------------------------

--
-- Table structure for table `tw1`
--

CREATE TABLE `tw1` (
  `id_tw1` int(5) NOT NULL,
  `id_tar` int(6) NOT NULL,
  `id_bidang` char(5) NOT NULL,
  `id_prog` char(6) NOT NULL,
  `id_keg` int(6) NOT NULL,
  `tw1` varchar(10) NOT NULL,
  `k` varchar(120) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `rp` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tw2`
--

CREATE TABLE `tw2` (
  `id_tw2` int(5) NOT NULL,
  `id_tw1` varchar(6) NOT NULL,
  `id_tar` int(6) NOT NULL,
  `id_bidang` char(5) NOT NULL,
  `id_prog` char(6) NOT NULL,
  `id_keg` int(6) NOT NULL,
  `tw2` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_evaluasi`
--

CREATE TABLE `t_evaluasi` (
  `id_target` int(5) NOT NULL,
  `id_bidang` char(5) NOT NULL,
  `id_prog` char(6) NOT NULL,
  `id_keg` int(6) NOT NULL,
  `tanggal` date NOT NULL,
  `output` varchar(250) NOT NULL,
  `target` varchar(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `anggaran` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_evaluasi`
--

INSERT INTO `t_evaluasi` (`id_target`, `id_bidang`, `id_prog`, `id_keg`, `tanggal`, `output`, `target`, `satuan`, `anggaran`) VALUES
(49, '02', '002', 1, '0000-00-00', 'Pengelolaan Pasar ikans', '302', 'kartu', '70000'),
(50, '02', '002', 2, '0000-00-00', 'Pengelolaan Pasar ikans', '302', 'vdv', '100000');

-- --------------------------------------------------------

--
-- Table structure for table `t_tw3`
--

CREATE TABLE `t_tw3` (
  `id_tw3` int(5) NOT NULL,
  `id_tw1` varchar(6) NOT NULL,
  `id_tar` int(6) NOT NULL,
  `id_bidang` char(5) NOT NULL,
  `id_prog` char(6) NOT NULL,
  `id_keg` int(6) NOT NULL,
  `tw3` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_tw4`
--

CREATE TABLE `t_tw4` (
  `id_tw4` int(5) NOT NULL,
  `id_tw1` varchar(6) NOT NULL,
  `id_tar` int(6) NOT NULL,
  `id_bidang` char(5) NOT NULL,
  `id_prog` char(6) NOT NULL,
  `id_keg` int(6) NOT NULL,
  `tw4` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bidang`
--
ALTER TABLE `bidang`
  ADD PRIMARY KEY (`id_bidang`);

--
-- Indexes for table `bulan`
--
ALTER TABLE `bulan`
  ADD PRIMARY KEY (`id_bulan`);

--
-- Indexes for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD PRIMARY KEY (`id_keg`),
  ADD KEY `id_prog` (`id_prog`),
  ADD KEY `id_prog_2` (`id_prog`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`id_prog`),
  ADD KEY `id_bidang` (`id_bidang`);

--
-- Indexes for table `tw1`
--
ALTER TABLE `tw1`
  ADD PRIMARY KEY (`id_tw1`),
  ADD KEY `id_bidang` (`id_bidang`) USING BTREE,
  ADD KEY `id_target` (`id_tar`) USING BTREE;

--
-- Indexes for table `tw2`
--
ALTER TABLE `tw2`
  ADD PRIMARY KEY (`id_tw2`),
  ADD KEY `id_bidang` (`id_bidang`) USING BTREE,
  ADD KEY `id_tar` (`id_tar`) USING BTREE;

--
-- Indexes for table `t_evaluasi`
--
ALTER TABLE `t_evaluasi`
  ADD PRIMARY KEY (`id_target`),
  ADD KEY `id_bidang` (`id_bidang`);

--
-- Indexes for table `t_tw3`
--
ALTER TABLE `t_tw3`
  ADD PRIMARY KEY (`id_tw3`);

--
-- Indexes for table `t_tw4`
--
ALTER TABLE `t_tw4`
  ADD PRIMARY KEY (`id_tw4`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kegiatan`
--
ALTER TABLE `kegiatan`
  MODIFY `id_keg` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tw1`
--
ALTER TABLE `tw1`
  MODIFY `id_tw1` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tw2`
--
ALTER TABLE `tw2`
  MODIFY `id_tw2` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `t_evaluasi`
--
ALTER TABLE `t_evaluasi`
  MODIFY `id_target` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `t_tw3`
--
ALTER TABLE `t_tw3`
  MODIFY `id_tw3` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `t_tw4`
--
ALTER TABLE `t_tw4`
  MODIFY `id_tw4` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD CONSTRAINT `kegiatan_ibfk_1` FOREIGN KEY (`id_prog`) REFERENCES `program` (`id_prog`);

--
-- Constraints for table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `program_ibfk_1` FOREIGN KEY (`id_bidang`) REFERENCES `bidang` (`id_bidang`);

--
-- Constraints for table `tw1`
--
ALTER TABLE `tw1`
  ADD CONSTRAINT `tw1_ibfk_2` FOREIGN KEY (`id_bidang`) REFERENCES `bidang` (`id_bidang`);

--
-- Constraints for table `tw2`
--
ALTER TABLE `tw2`
  ADD CONSTRAINT `tw2_ibfk_1` FOREIGN KEY (`id_bidang`) REFERENCES `bidang` (`id_bidang`);

--
-- Constraints for table `t_evaluasi`
--
ALTER TABLE `t_evaluasi`
  ADD CONSTRAINT `t_evaluasi_ibfk_1` FOREIGN KEY (`id_bidang`) REFERENCES `bidang` (`id_bidang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
